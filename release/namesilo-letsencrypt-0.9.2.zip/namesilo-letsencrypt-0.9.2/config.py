# Get your API Key from: https://www.namesilo.com/account_api.php
apikey = "YOUR_API_KEY"
# Minutes to wait for DNS changes to complete.
wait = 25
